import os
import asyncio
import logging
import sqlite3
from contextlib import closing
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton,
    LabeledPrice, PreCheckoutQuery, ReplyKeyboardMarkup, KeyboardButton
)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.exceptions import TelegramBadRequest

TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_IDS = {int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
CHANNEL_ID = os.getenv("CHANNEL_ID", "").strip()  # e.g. @yourchannel or -1001234567890
CHANNEL_URL = os.getenv("CHANNEL_URL", "").strip()  # e.g. https://t.me/yourchannel
DB_PATH = os.getenv("DB_PATH", "metroshop.sqlite3")

if not TOKEN:
    raise RuntimeError("Set BOT_TOKEN in environment variables.")
if not ADMIN_IDS:
    raise RuntimeError("Set ADMIN_IDS to your numeric Telegram user ID.")

logging.basicConfig(level=logging.INFO)
bot = Bot(TOKEN)
dp = Dispatcher()

CATEGORIES = {
    "sites": ("🌐 Сайты", 100),
    "accounts": ("📱 Telegram-аккаунты", 50),
    "gifts": ("🎁 Подарки", 15),
}
SEED_PRODUCTS = [
    ("sites", "Сайт №1", 100, "Пример сайта №1. Изображение можно заменить через админ-панель."),
    ("sites", "Сайт №2", 100, "Пример сайта №2. Изображение можно заменить через админ-панель."),
    ("sites", "Сайт №3", 100, "Пример сайта №3. Изображение можно заменить через админ-панель."),
    ("accounts", "Аккаунт — США 🇺🇸", 50, "Указывайте только аккаунты, которыми вы вправе распоряжаться."),
    ("accounts", "Аккаунт — Великобритания 🇬🇧", 50, "Указывайте только аккаунты, которыми вы вправе распоряжаться."),
    ("accounts", "Аккаунт — Германия 🇩🇪", 50, "Указывайте только аккаунты, которыми вы вправе распоряжаться."),
    ("accounts", "Аккаунт — Франция 🇫🇷", 50, "Указывайте только аккаунты, которыми вы вправе распоряжаться."),
    ("accounts", "Аккаунт — Испания 🇪🇸", 50, "Указывайте только аккаунты, которыми вы вправе распоряжаться."),
    ("accounts", "Аккаунт — Италия 🇮🇹", 50, "Указывайте только аккаунты, которыми вы вправе распоряжаться."),
    ("accounts", "Аккаунт — Нидерланды 🇳🇱", 50, "Указывайте только аккаунты, которыми вы вправе распоряжаться."),
    ("accounts", "Аккаунт — Польша 🇵🇱", 50, "Указывайте только аккаунты, которыми вы вправе распоряжаться."),
    ("accounts", "Аккаунт — Швеция 🇸🇪", 50, "Указывайте только аккаунты, которыми вы вправе распоряжаться."),
    ("accounts", "Аккаунт — Канада 🇨🇦", 50, "Указывайте только аккаунты, которыми вы вправе распоряжаться."),
    ("accounts", "Аккаунт — Япония 🇯🇵", 50, "Указывайте только аккаунты, которыми вы вправе распоряжаться."),
    ("accounts", "Аккаунт — Турция 🇹🇷", 50, "Указывайте только аккаунты, которыми вы вправе распоряжаться."),
    ("accounts", "Аккаунт — Казахстан 🇰🇿", 50, "Указывайте только аккаунты, которыми вы вправе распоряжаться."),
    ("gifts", "Мишка 🧸", 15, "Подарок «Мишка». Уточните доступность и реальную цену перед продажей."),
    ("gifts", "Сердце ❤️", 15, "Подарок «Сердце». Уточните доступность и реальную цену перед продажей."),
    ("gifts", "Роза 🌹", 25, "Подарок «Роза». Уточните доступность и реальную цену перед продажей."),
    ("gifts", "Подарок 🎁", 25, "Подарок Telegram. Уточните доступность и реальную цену перед продажей."),
    ("gifts", "Торт 🎂", 50, "Подарок «Торт». Уточните доступность и реальную цену перед продажей."),
    ("gifts", "Шампанское 🥂", 50, "Подарок «Шампанское». Уточните доступность и реальную цену перед продажей."),
    ("gifts", "Цветы 💐", 50, "Подарок «Цветы». Уточните доступность и реальную цену перед продажей."),
    ("gifts", "Кубок 🏆", 100, "Подарок «Кубок». Уточните доступность и реальную цену перед продажей."),
    ("gifts", "Кольцо 💍", 100, "Подарок «Кольцо». Уточните доступность и реальную цену перед продажей."),
    ("gifts", "Алмазик 💎", 100, "Подарок «Алмазик». Уточните доступность и реальную цену перед продажей."),
]

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with closing(db()) as con:
        con.execute("""CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT NOT NULL, name TEXT NOT NULL, price INTEGER NOT NULL,
            description TEXT DEFAULT '', photo_id TEXT DEFAULT '', active INTEGER DEFAULT 1
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL, price INTEGER NOT NULL,
            telegram_charge_id TEXT UNIQUE, status TEXT NOT NULL DEFAULT 'paid',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        count = con.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        if count == 0:
            con.executemany(
                "INSERT INTO products(category,name,price,description) VALUES(?,?,?,?)",
                SEED_PRODUCTS
            )
        con.commit()

def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS

async def subscribed(user_id: int) -> bool:
    if not CHANNEL_ID:
        return True
    try:
        member = await bot.get_chat_member(CHANNEL_ID, user_id)
        return member.status in ("creator", "administrator", "member")
    except Exception:
        logging.exception("Subscription check failed; verify bot is an admin/member of the channel.")
        return False

def main_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🌐 Сайты", callback_data="cat:sites")],
        [InlineKeyboardButton(text="📱 Telegram-аккаунты", callback_data="cat:accounts")],
        [InlineKeyboardButton(text="🎁 Подарки", callback_data="cat:gifts")],
        [InlineKeyboardButton(text="👤 Поддержка", callback_data="support")],
    ])

def subscription_kb():
    rows = []
    if CHANNEL_URL:
        rows.append([InlineKeyboardButton(text="📢 Подписаться на канал", url=CHANNEL_URL)])
    rows.append([InlineKeyboardButton(text="✅ Проверить подписку", callback_data="check_sub")])
    return InlineKeyboardMarkup(inline_keyboard=rows)

def admin_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📦 Товары", callback_data="admin:products")],
        [InlineKeyboardButton(text="➕ Добавить товар", callback_data="admin:add")],
        [InlineKeyboardButton(text="📊 Статистика и заказы", callback_data="admin:stats")],
        [InlineKeyboardButton(text="📢 Рассылка", callback_data="admin:broadcast")],
    ])

async def show_home(target, user_id):
    if CHANNEL_ID and not await subscribed(user_id):
        text = "💙 <b>Добро пожаловать в METROSHOP!</b>\n\nЧтобы пользоваться магазином, подпишись на наш канал и нажми «Проверить подписку»."
        if isinstance(target, Message):
            await target.answer(text, reply_markup=subscription_kb(), parse_mode="HTML")
        else:
            await target.message.edit_text(text, reply_markup=subscription_kb(), parse_mode="HTML")
        return
    text = "💙 <b>METROSHOP</b>\n\nВыбери раздел магазина:"
    if isinstance(target, Message):
        await target.answer(text, reply_markup=main_kb(), parse_mode="HTML")
    else:
        await target.message.edit_text(text, reply_markup=main_kb(), parse_mode="HTML")

@dp.message(CommandStart())
async def start(message: Message):
    await show_home(message, message.from_user.id)

@dp.callback_query(F.data == "check_sub")
async def check_sub(callback: CallbackQuery):
    if await subscribed(callback.from_user.id):
        await callback.answer("Подписка подтверждена! 💙")
        await show_home(callback, callback.from_user.id)
    else:
        await callback.answer("Пока не вижу подписку. Подпишись и попробуй снова.", show_alert=True)

@dp.callback_query(F.data.startswith("cat:"))
async def category(callback: CallbackQuery):
    if CHANNEL_ID and not await subscribed(callback.from_user.id):
        await callback.answer("Сначала подпишись на канал.", show_alert=True)
        await show_home(callback, callback.from_user.id)
        return
    cat = callback.data.split(":", 1)[1]
    if cat not in CATEGORIES:
        await callback.answer("Категория не найдена.", show_alert=True)
        return
    title = CATEGORIES[cat][0]
    with closing(db()) as con:
        products = con.execute(
            "SELECT * FROM products WHERE category=? AND active=1 ORDER BY id", (cat,)
        ).fetchall()
    builder = InlineKeyboardBuilder()
    for p in products:
        builder.button(text=f"{p['name']} — {p['price']} ⭐", callback_data=f"product:{p['id']}")
    builder.button(text="⬅️ Главное меню", callback_data="home")
    builder.adjust(1)
    await callback.message.edit_text(
        f"💙 <b>{title}</b>\n\nВыбери товар:",
        reply_markup=builder.as_markup(), parse_mode="HTML"
    )
    await callback.answer()

@dp.callback_query(F.data == "home")
async def home(callback: CallbackQuery):
    await show_home(callback, callback.from_user.id)
    await callback.answer()

@dp.callback_query(F.data.startswith("product:"))
async def product_detail(callback: CallbackQuery):
    try:
        product_id = int(callback.data.split(":")[1])
    except ValueError:
        await callback.answer("Товар не найден.", show_alert=True)
        return
    with closing(db()) as con:
        p = con.execute("SELECT * FROM products WHERE id=? AND active=1", (product_id,)).fetchone()
    if not p:
        await callback.answer("Товар больше недоступен.", show_alert=True)
        return
    text = f"💙 <b>{p['name']}</b>\n\n{p['description'] or 'Без описания'}\n\n⭐ Цена: <b>{p['price']} Stars</b>"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"🛒 Купить за {p['price']} ⭐", callback_data=f"buy:{p['id']}")],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data=f"cat:{p['category']}")],
    ])
    try:
        if p["photo_id"]:
            await callback.message.answer_photo(p["photo_id"], caption=text, reply_markup=kb, parse_mode="HTML")
        else:
            await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    except TelegramBadRequest:
        await callback.message.answer(text, reply_markup=kb, parse_mode="HTML")
    await callback.answer()

@dp.callback_query(F.data.startswith("buy:"))
async def buy(callback: CallbackQuery):
    if CHANNEL_ID and not await subscribed(callback.from_user.id):
        await callback.answer("Сначала подпишись на канал.", show_alert=True)
        await show_home(callback, callback.from_user.id)
        return
    try:
        product_id = int(callback.data.split(":")[1])
    except ValueError:
        await callback.answer("Товар не найден.", show_alert=True)
        return
    with closing(db()) as con:
        p = con.execute("SELECT * FROM products WHERE id=? AND active=1", (product_id,)).fetchone()
    if not p:
        await callback.answer("Товар недоступен.", show_alert=True)
        return
    # Telegram Stars invoices use currency XTR and an empty provider_token.
    await bot.send_invoice(
        chat_id=callback.from_user.id,
        title=p["name"][:32],
        description=(p["description"] or p["name"])[:255],
        payload=f"product:{p['id']}:{callback.from_user.id}",
        provider_token="",
        currency="XTR",
        prices=[LabeledPrice(label=p["name"][:32], amount=int(p["price"]))],
    )
    await callback.answer("Счёт отправлен в личные сообщения 💙")

@dp.pre_checkout_query()
async def pre_checkout(query: PreCheckoutQuery):
    try:
        parts = query.invoice_payload.split(":")
        product_id, buyer_id = int(parts[1]), int(parts[2])
        if buyer_id != query.from_user.id:
            await query.answer(ok=False, error_message="Этот счёт создан для другого пользователя.")
            return
        with closing(db()) as con:
            p = con.execute("SELECT * FROM products WHERE id=? AND active=1", (product_id,)).fetchone()
        if not p or int(p["price"]) != query.total_amount or query.currency != "XTR":
            await query.answer(ok=False, error_message="Цена изменилась или товар недоступен. Открой каталог заново.")
            return
        await query.answer(ok=True)
    except Exception:
        await query.answer(ok=False, error_message="Не удалось проверить заказ. Попробуй ещё раз.")

@dp.message(F.successful_payment)
async def successful_payment(message: Message):
    payment = message.successful_payment
    try:
        parts = payment.invoice_payload.split(":")
        product_id, buyer_id = int(parts[1]), int(parts[2])
    except Exception:
        await message.answer("Оплата получена, но заказ нужно проверить вручную. Напиши в поддержку.")
        return
    if buyer_id != message.from_user.id:
        await message.answer("Оплата получена. Заказ отправлен на ручную проверку.")
        return
    with closing(db()) as con:
        p = con.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
        name = p["name"] if p else "Товар"
        con.execute(
            """INSERT OR IGNORE INTO orders(user_id,product_id,product_name,price,telegram_charge_id,status)
               VALUES(?,?,?,?,?,'paid')""",
            (message.from_user.id, product_id, name, payment.total_amount, payment.telegram_payment_charge_id)
        )
        con.commit()
    await message.answer(
        f"💙 <b>Оплата прошла успешно!</b>\n\nЗаказ № сохранён.\nТовар: {name}\nОплачено: {payment.total_amount} ⭐\n\nПродавец свяжется с тобой для выдачи товара.",
        parse_mode="HTML"
    )
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(admin_id, f"🛒 <b>Новый оплаченный заказ</b>\nПокупатель: <code>{message.from_user.id}</code>\nТовар: {name}\nСумма: {payment.total_amount} ⭐", parse_mode="HTML")
        except Exception:
            pass

@dp.callback_query(F.data == "support")
async def support(callback: CallbackQuery):
    await callback.message.edit_text("💙 По вопросам заказа напиши администратору магазина.")
    await callback.answer()

@dp.message(Command("admin"))
async def admin(message: Message):
    if not is_admin(message.from_user.id):
        return
    await message.answer("👑 <b>Админ-панель METROSHOP</b>", reply_markup=admin_kb(), parse_mode="HTML")

@dp.callback_query(F.data.startswith("admin:"))
async def admin_actions(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("Нет доступа.", show_alert=True)
        return
    action = callback.data.split(":")[1]
    if action == "products":
        with closing(db()) as con:
            rows = con.execute("SELECT id,name,price,category,active FROM products ORDER BY id").fetchall()
        lines = ["📦 <b>Товары</b>"]
        for p in rows[:80]:
            lines.append(f"#{p['id']} [{p['category']}] {p['name']} — {p['price']} ⭐ {'✅' if p['active'] else '⛔'}")
        lines.append("\nЧтобы добавить товар, нажми «Добавить товар».")
        await callback.message.edit_text("\n".join(lines), reply_markup=admin_kb(), parse_mode="HTML")
    elif action == "stats":
        with closing(db()) as con:
            users = con.execute("SELECT COUNT(DISTINCT user_id) FROM orders").fetchone()[0]
            orders = con.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
            revenue = con.execute("SELECT COALESCE(SUM(price),0) FROM orders").fetchone()[0]
            recent = con.execute("SELECT id,user_id,product_name,price FROM orders ORDER BY id DESC LIMIT 10").fetchall()
        text = f"📊 <b>Статистика</b>\nОплаченных заказов: {orders}\nПокупателей: {users}\nСумма заказов: {revenue} ⭐\n\n<b>Последние заказы:</b>"
        for o in recent:
            text += f"\n#{o['id']} — {o['product_name']} — {o['price']} ⭐ (ID {o['user_id']})"
        await callback.message.edit_text(text, reply_markup=admin_kb(), parse_mode="HTML")
    elif action == "add":
        await callback.message.answer(
            "Чтобы добавить товар, отправь сообщение в формате:\n"
            "<code>/add категория | название | цена | описание</code>\n"
            "Категория: sites, accounts или gifts.\n"
            "Затем ответь командой /setphoto ID на фото товара, чтобы назначить изображение.",
            parse_mode="HTML"
        )
    elif action == "broadcast":
        await callback.message.answer("Для рассылки используй команду:\n<code>/broadcast текст сообщения</code>", parse_mode="HTML")
    await callback.answer()

@dp.message(Command("add"))
async def add_product(message: Message):
    if not is_admin(message.from_user.id):
        return
    raw = message.text.partition(" ")[2]
    parts = [x.strip() for x in raw.split("|", 3)]
    if len(parts) != 4 or parts[0] not in CATEGORIES or not parts[2].isdigit() or int(parts[2]) < 1:
        await message.answer("Формат: /add sites | Название | 100 | Описание\nКатегория: sites, accounts, gifts")
        return
    cat, name, price, desc = parts
    with closing(db()) as con:
        cur = con.execute("INSERT INTO products(category,name,price,description) VALUES(?,?,?,?)", (cat, name, int(price), desc))
        con.commit()
        new_id = cur.lastrowid
    await message.answer(f"✅ Товар добавлен, ID: {new_id}\nЧтобы поставить фото, отправь фото с подписью /setphoto {new_id}")

@dp.message(Command("setphoto"))
async def set_photo(message: Message):
    if not is_admin(message.from_user.id):
        return
    if not message.photo:
        await message.answer("Отправь фотографию с подписью /setphoto ID или ответь этой командой на фотографию.")
        return
    try:
        product_id = int(message.caption.partition(" ")[2].strip())
    except ValueError:
        await message.answer("Укажи ID: подпись к фото должна быть /setphoto 12")
        return
    photo_id = message.photo[-1].file_id
    with closing(db()) as con:
        cur = con.execute("UPDATE products SET photo_id=? WHERE id=?", (photo_id, product_id))
        con.commit()
    await message.answer("🖼 Фото сохранено." if cur.rowcount else "Товар с таким ID не найден.")

@dp.message(Command("price"))
async def change_price(message: Message):
    if not is_admin(message.from_user.id):
        return
    parts = message.text.split()
    if len(parts) != 3 or not parts[1].isdigit() or not parts[2].isdigit() or int(parts[2]) < 1:
        await message.answer("Формат: /price ID новая_цена\nНапример: /price 4 75")
        return
    with closing(db()) as con:
        cur = con.execute("UPDATE products SET price=? WHERE id=?", (int(parts[2]), int(parts[1])))
        con.commit()
    await message.answer("✅ Цена изменена." if cur.rowcount else "Товар не найден.")

@dp.message(Command("hide"))
async def hide_product(message: Message):
    if not is_admin(message.from_user.id):
        return
    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        await message.answer("Формат: /hide ID")
        return
    with closing(db()) as con:
        cur = con.execute("UPDATE products SET active=0 WHERE id=?", (int(parts[1]),))
        con.commit()
    await message.answer("Товар скрыт." if cur.rowcount else "Товар не найден.")

@dp.message(Command("broadcast"))
async def broadcast(message: Message):
    if not is_admin(message.from_user.id):
        return
    text = message.text.partition(" ")[2].strip()
    if not text:
        await message.answer("Формат: /broadcast Текст рассылки")
        return
    with closing(db()) as con:
        # This bot only stores buyers in the orders table; broadcast to known customers.
        ids = [r[0] for r in con.execute("SELECT DISTINCT user_id FROM orders").fetchall()]
    sent = 0
    for uid in ids:
        try:
            await bot.send_message(uid, text)
            sent += 1
            await asyncio.sleep(0.05)
        except Exception:
            pass
    await message.answer(f"📢 Рассылка завершена: отправлено {sent} пользователям с заказами.")

async def main():
    init_db()
    logging.info("METROSHOP is starting")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
