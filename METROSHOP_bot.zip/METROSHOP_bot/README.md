# METROSHOP Telegram bot

A starter Telegram shop bot using Python, aiogram 3, SQLite and Telegram Stars.

## Setup

1. Create a bot with [@BotFather](https://t.me/BotFather) and copy its token.
2. Find your numeric Telegram user ID using a trusted ID bot or a bot you control.
3. Install Python 3.11+ and run:

```bash
pip install -r requirements.txt
```

4. Set environment variables:
   - `BOT_TOKEN`: token from BotFather
   - `ADMIN_IDS`: your numeric Telegram user ID; multiple IDs separated by commas
   - `CHANNEL_ID`: optional channel username such as `@mychannel` or numeric channel ID
   - `CHANNEL_URL`: optional public channel URL, e.g. `https://t.me/mychannel`
5. Make the shop bot an administrator in the required channel so it can check membership.
6. Start the bot:

```bash
python bot.py
```

The SQLite database is created automatically as `metroshop.sqlite3`.

## Admin commands

- `/admin` — admin panel
- `/add sites | Site name | 100 | Description` — add product
- Send a photo with caption `/setphoto PRODUCT_ID` — attach photo
- `/price PRODUCT_ID NEW_PRICE` — change price in Stars
- `/hide PRODUCT_ID` — hide a product
- `/broadcast Your message` — sends to users who have completed an order

Products are seeded on first start. Edit or hide seed products as needed.

## Important limitations / production checklist

- This is a starter implementation. Orders are recorded and admins are notified, but delivery is manual; configure real fulfillment before advertising automatic delivery.
- Telegram Stars invoices use currency `XTR` and an empty provider token. Test purchases carefully before launch.
- Digital goods and services sold inside Telegram bots must use Telegram Stars. See Telegram's current Bot Payments documentation and comply with its rules.
- Keep the bot token secret. Never commit `.env` files or tokens to GitHub.
- For reliable 24/7 service, use a host that supports persistent background workers and persistent disk/volume for SQLite, or move the database to a managed database.
- Mandatory subscription requires `CHANNEL_ID`, `CHANNEL_URL`, and the bot having sufficient channel access to check membership.
- Selling or transferring Telegram accounts may violate Telegram's terms and can expose buyers to fraud or account loss. Only list products you are authorized to sell and verify Telegram's rules before enabling that category.
- Telegram gift availability and prices can change; seed gift names/prices are placeholders and must be checked against current official availability before sales.
